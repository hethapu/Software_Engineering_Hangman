function id(a) {
  // Form-Feed
  // Vertical Tab
   // No-Break Space
  ᠎// Mongolian Vowel Separator
   // En quad
   // Em quad
   // En space
   // Em space
   // Three-Per-Em Space
   // Four-Per-Em Space
   // Six-Per-Em Space
   // Figure Space
   // Punctuation Space
   // Thin Space
   // Hair Space
   // Narrow No-Break Space
   // Medium Mathematical Space
  　// Ideographic Space
  return a;
}
