print(a / /[a-z]/);
