package hangman

class Phrase {
	String Category
	String Value

    static constraints = {
    }
}
